-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: motosdb
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auditoria_ventas`
--

DROP TABLE IF EXISTS `auditoria_ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditoria_ventas` (
  `id_auditoria` int NOT NULL AUTO_INCREMENT,
  `id_moto` int NOT NULL,
  `id_comprador` int NOT NULL,
  `precio_venta` decimal(10,2) DEFAULT NULL,
  `fecha_venta` date DEFAULT NULL,
  `tipo_venta` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_auditoria`),
  KEY `id_moto` (`id_moto`),
  KEY `id_comprador` (`id_comprador`),
  CONSTRAINT `auditoria_ventas_ibfk_1` FOREIGN KEY (`id_moto`) REFERENCES `moto` (`id_moto`) ON DELETE CASCADE,
  CONSTRAINT `auditoria_ventas_ibfk_2` FOREIGN KEY (`id_comprador`) REFERENCES `propietario` (`id_propietario`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria_ventas`
--

LOCK TABLES `auditoria_ventas` WRITE;
/*!40000 ALTER TABLE `auditoria_ventas` DISABLE KEYS */;
/*!40000 ALTER TABLE `auditoria_ventas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `color`
--

DROP TABLE IF EXISTS `color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `color` (
  `id_color` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id_color`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `color`
--

LOCK TABLES `color` WRITE;
/*!40000 ALTER TABLE `color` DISABLE KEYS */;
INSERT INTO `color` VALUES (1,'Rojo'),(2,'Azul'),(3,'Verde'),(4,'Negro'),(5,'Blanco'),(6,'Gris'),(7,'Amarillo'),(8,'Naranja'),(9,'Violeta'),(10,'Marron');
/*!40000 ALTER TABLE `color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marca`
--

DROP TABLE IF EXISTS `marca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marca` (
  `id_marca` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marca`
--

LOCK TABLES `marca` WRITE;
/*!40000 ALTER TABLE `marca` DISABLE KEYS */;
INSERT INTO `marca` VALUES (1,'Honda'),(2,'Yamaha'),(3,'Kawasaki'),(4,'Suzuki'),(5,'BMW'),(6,'Ducati'),(7,'Harley-Davidson'),(8,'KTM'),(9,'Triumph'),(10,'Benelli');
/*!40000 ALTER TABLE `marca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modelo`
--

DROP TABLE IF EXISTS `modelo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modelo` (
  `id_modelo` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `id_marca` int NOT NULL,
  PRIMARY KEY (`id_modelo`),
  KEY `id_marca` (`id_marca`),
  CONSTRAINT `modelo_ibfk_1` FOREIGN KEY (`id_marca`) REFERENCES `marca` (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modelo`
--

LOCK TABLES `modelo` WRITE;
/*!40000 ALTER TABLE `modelo` DISABLE KEYS */;
INSERT INTO `modelo` VALUES (1,'CBR600RR',1),(2,'R1',2),(3,'Ninja ZX-10R',3),(4,'GSX-R1000',4),(5,'S1000RR',5),(6,'Monster 821',6),(7,'Street Glide',7),(8,'Duke 790',8),(9,'Tiger 900',9),(10,'Leoncino 500',10);
/*!40000 ALTER TABLE `modelo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moto`
--

DROP TABLE IF EXISTS `moto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `moto` (
  `id_moto` int NOT NULL AUTO_INCREMENT,
  `id_modelo` int NOT NULL,
  `id_tipo` int NOT NULL,
  `id_propietario` int NOT NULL,
  `id_color` int NOT NULL,
  PRIMARY KEY (`id_moto`),
  KEY `id_modelo` (`id_modelo`),
  KEY `id_tipo` (`id_tipo`),
  KEY `id_propietario` (`id_propietario`),
  KEY `id_color` (`id_color`),
  CONSTRAINT `moto_ibfk_1` FOREIGN KEY (`id_modelo`) REFERENCES `modelo` (`id_modelo`),
  CONSTRAINT `moto_ibfk_2` FOREIGN KEY (`id_tipo`) REFERENCES `tipo` (`id_tipo`),
  CONSTRAINT `moto_ibfk_3` FOREIGN KEY (`id_propietario`) REFERENCES `propietario` (`id_propietario`),
  CONSTRAINT `moto_ibfk_4` FOREIGN KEY (`id_color`) REFERENCES `color` (`id_color`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moto`
--

LOCK TABLES `moto` WRITE;
/*!40000 ALTER TABLE `moto` DISABLE KEYS */;
INSERT INTO `moto` VALUES (1,1,1,1,1),(2,2,2,2,2),(3,3,3,3,3),(4,4,4,4,4),(5,5,5,5,5),(6,6,6,6,6),(7,7,7,7,7),(8,8,8,8,8),(9,9,9,9,9),(10,10,10,10,10);
/*!40000 ALTER TABLE `moto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `propietario`
--

DROP TABLE IF EXISTS `propietario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `propietario` (
  `id_propietario` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_propietario`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `propietario`
--

LOCK TABLES `propietario` WRITE;
/*!40000 ALTER TABLE `propietario` DISABLE KEYS */;
INSERT INTO `propietario` VALUES (1,'Juan','Perez','Av Libertador 123','juanperez@gmail.com','123456789'),(2,'Ana','Gonzalez','Calle Falsa 456','anagonzalez@gmail.com','987654321'),(3,'Carlos','Lopez','Av San Martin 789','carloslopez@gmail.com','456789123'),(4,'Luis','Martinez','Calle Primavera 101','luismartinez@gmail.com','789123456'),(5,'Sofia','Ruiz','Calle Secundaria 202','sofiaruiz@gmail.com','321654987'),(6,'Mario','Ramos','Av Mitre 303','marioramos@gmail.com','123789456'),(7,'Lucia','Fernandez','Calle 25 de Mayo 456','luciafernandez@gmail.com','456321789'),(8,'Pedro','Silva','Av Colon 789','pedrosilva@gmail.com','789456123'),(9,'Camila','Torres','Calle Belgrano 101','camilatorres@gmail.com','654987321'),(10,'Diego','Mendez','Av Sarmiento 202','diegomendez@gmail.com','987123654');
/*!40000 ALTER TABLE `propietario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seguro`
--

DROP TABLE IF EXISTS `seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seguro` (
  `id_seguro` int NOT NULL AUTO_INCREMENT,
  `id_moto` int NOT NULL,
  `empresa` varchar(50) NOT NULL,
  `poliza` varchar(50) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `tipo_cobertura` varchar(50) DEFAULT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_seguro`),
  KEY `id_moto` (`id_moto`),
  CONSTRAINT `seguro_ibfk_1` FOREIGN KEY (`id_moto`) REFERENCES `moto` (`id_moto`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seguro`
--

LOCK TABLES `seguro` WRITE;
/*!40000 ALTER TABLE `seguro` DISABLE KEYS */;
INSERT INTO `seguro` VALUES (1,1,'Seguros Axa','POL123','2025-01-01','2026-01-01','Completa',500.00),(2,2,'La Caja','POL124','2025-02-01','2026-02-01','Terceros',300.00),(3,3,'Sancor','POL125','2025-03-01','2026-03-01','Combinada',450.00),(4,4,'Federacion Patronal','POL126','2025-04-01','2026-04-01','Limitada',350.00),(5,5,'Triunfo Seguros','POL127','2025-05-01','2026-05-01','Todo Riesgo',600.00),(6,6,'Rivadavia Seguros','POL128','2025-06-01','2026-06-01','Completa',550.00),(7,7,'Mapfre','POL129','2025-07-01','2026-07-01','Terceros',320.00),(8,8,'Zurich','POL130','2025-08-01','2026-08-01','Combinada',480.00),(9,9,'Provincia Seguros','POL131','2025-09-01','2026-09-01','Limitada',370.00),(10,10,'Allianz','POL132','2025-10-01','2026-10-01','Todo Riesgo',620.00);
/*!40000 ALTER TABLE `seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo`
--

DROP TABLE IF EXISTS `tipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo` (
  `id_tipo` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id_tipo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo`
--

LOCK TABLES `tipo` WRITE;
/*!40000 ALTER TABLE `tipo` DISABLE KEYS */;
INSERT INTO `tipo` VALUES (1,'Deportiva'),(2,'Cruiser'),(3,'Touring'),(4,'Off-Road'),(5,'Scooter'),(6,'Naked'),(7,'Chopper'),(8,'Enduro'),(9,'Custom'),(10,'Electrica');
/*!40000 ALTER TABLE `tipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `venta`
--

DROP TABLE IF EXISTS `venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `venta` (
  `id_venta` int NOT NULL AUTO_INCREMENT,
  `id_moto` int NOT NULL,
  `id_comprador` int NOT NULL,
  `fecha_venta` date NOT NULL,
  `precio_venta` decimal(10,2) DEFAULT NULL,
  `tipo_venta` varchar(50) NOT NULL,
  PRIMARY KEY (`id_venta`),
  KEY `id_moto` (`id_moto`),
  KEY `id_comprador` (`id_comprador`),
  CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`id_moto`) REFERENCES `moto` (`id_moto`) ON DELETE CASCADE,
  CONSTRAINT `venta_ibfk_2` FOREIGN KEY (`id_comprador`) REFERENCES `propietario` (`id_propietario`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `venta`
--

LOCK TABLES `venta` WRITE;
/*!40000 ALTER TABLE `venta` DISABLE KEYS */;
INSERT INTO `venta` VALUES (1,1,6,'2025-01-15',12000.00,'Compra Nueva'),(2,2,7,'2025-02-20',15000.00,'Compra Usada'),(3,3,8,'2025-03-25',18000.00,'Compra Nueva'),(4,4,9,'2025-04-10',16000.00,'Compra Usada'),(5,5,10,'2025-05-05',20000.00,'Compra Nueva'),(6,6,1,'2025-06-12',13000.00,'Compra Usada'),(7,7,2,'2025-07-18',15500.00,'Compra Nueva'),(8,8,3,'2025-08-22',17000.00,'Compra Usada'),(9,9,4,'2025-09-30',17500.00,'Compra Nueva'),(10,10,5,'2025-10-25',19000.00,'Compra Usada');
/*!40000 ALTER TABLE `venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `vista_motos_propietarios`
--

DROP TABLE IF EXISTS `vista_motos_propietarios`;
/*!50001 DROP VIEW IF EXISTS `vista_motos_propietarios`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vista_motos_propietarios` AS SELECT 
 1 AS `id_moto`,
 1 AS `id_modelo`,
 1 AS `id_tipo`,
 1 AS `propietario_nombre`,
 1 AS `propietario_apellido`,
 1 AS `tipo_moto`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vista_motos_propietarios`
--

/*!50001 DROP VIEW IF EXISTS `vista_motos_propietarios`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vista_motos_propietarios` AS select `m`.`id_moto` AS `id_moto`,`m`.`id_modelo` AS `id_modelo`,`m`.`id_tipo` AS `id_tipo`,`p`.`nombre` AS `propietario_nombre`,`p`.`apellido` AS `propietario_apellido`,`t`.`nombre` AS `tipo_moto` from ((`moto` `m` join `propietario` `p` on((`m`.`id_propietario` = `p`.`id_propietario`))) join `tipo` `t` on((`m`.`id_tipo` = `t`.`id_tipo`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-23 14:10:08
