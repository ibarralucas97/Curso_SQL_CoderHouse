-- PROCEDIMIENTO ALMACENADO 1 CORREGIDO DE ENTREGA 2: RegistrarVenta
DELIMITER $$

CREATE PROCEDURE RegistrarVenta(
    IN p_id_moto INT,
    IN p_id_comprador INT,
    IN p_fecha_venta DATE,
    IN p_precio_venta DECIMAL(10,2),
    IN p_tipo_venta VARCHAR(50)
)
BEGIN
    -- Insertar la venta en la tabla VENTA
    INSERT INTO VENTA (id_moto, id_comprador, fecha_venta, precio_venta, tipo_venta)
    VALUES (p_id_moto, p_id_comprador, p_fecha_venta, p_precio_venta, p_tipo_venta);

    -- Actualizar el propietario en la tabla MOTO
    UPDATE MOTO
    SET id_propietario = p_id_comprador
    WHERE id_moto = p_id_moto;
END $$

DELIMITER ;
-- PRUEBA EJECUCION
CALL RegistrarVenta(3, 2, '2025-05-15', 15000.00, 'Compra Usada');

-- PROCEDIMIENTO ALMACENARO 2: ObtenerVentasPorFecha
DELIMITER $$

CREATE PROCEDURE ObtenerVentasPorFecha(
    IN p_fecha_inicio DATE,
    IN p_fecha_fin DATE
)
BEGIN
    -- Obtener todas las ventas dentro del rango de fechas
    SELECT * FROM VENTA
    WHERE fecha_venta BETWEEN p_fecha_inicio AND p_fecha_fin;
END $$

DELIMITER ;
-- PRUEBA EJECUCION 
CALL ObtenerVentasPorFecha('2025-01-01', '2025-12-31');







