-- TCL

START TRANSACTION;

-- Insertamos una venta
INSERT INTO VENTA (id_moto, id_comprador, fecha_venta, precio_venta, tipo_venta)
VALUES (3, 4, '2025-07-01', 16000.00, 'Compra Usada');

-- Establecer un SAVEPOINT
SAVEPOINT VentaPaso1;

-- Intentamos otra venta
INSERT INTO VENTA (id_moto, id_comprador, fecha_venta, precio_venta, tipo_venta)
VALUES (4, 5, '2025-07-02', 17000.00, 'Compra Nueva');

-- Si salio todo bien hacemos:
COMMIT;

-- Si algo sale mal hacemos:
-- ROLLBACK TO VentaPaso1;

