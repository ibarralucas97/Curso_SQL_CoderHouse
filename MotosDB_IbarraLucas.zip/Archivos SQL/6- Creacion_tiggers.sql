-- TRIGGER PARA AUDITORÍA DE VENTAS

CREATE TABLE AUDITORIA_VENTAS (
    id_auditoria INT AUTO_INCREMENT PRIMARY KEY,
    id_moto INT NOT NULL,
    id_comprador INT NOT NULL,
    precio_venta DECIMAL(10,2),
    fecha_venta DATE,
    tipo_venta VARCHAR(50),
    FOREIGN KEY (id_moto) REFERENCES MOTO(id_moto) ON DELETE CASCADE,
    FOREIGN KEY (id_comprador) REFERENCES PROPIETARIO(id_propietario) ON DELETE CASCADE
);

-- Trigger 
DELIMITER $$

CREATE TRIGGER AuditarVenta
AFTER INSERT ON VENTA
FOR EACH ROW
BEGIN
    -- Insertamos un registro en la tabla de auditoría con todos los datos necesarios
    INSERT INTO AUDITORIA_VENTAS (id_moto, id_comprador, precio_venta, fecha_venta, tipo_venta)
    VALUES (NEW.id_moto, NEW.id_comprador, NEW.precio_venta, NEW.fecha_venta, NEW.tipo_venta);
END $$

DELIMITER ;



