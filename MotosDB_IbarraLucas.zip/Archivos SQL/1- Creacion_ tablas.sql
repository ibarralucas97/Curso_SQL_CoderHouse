DROP DATABASE IF EXISTS MotosDB;
-- Crear la base
CREATE DATABASE MotosDB;
USE MotosDB;

-- Tabla: COLORES
CREATE TABLE COLOR (
    id_color INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL
);

-- Tabla: MARCAS
CREATE TABLE MARCA (
    id_marca INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL
);

-- Tabla: TIPOS
CREATE TABLE TIPO (
    id_tipo INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL
);

-- Tabla: PROPIETARIOS
CREATE TABLE PROPIETARIO (
    id_propietario INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    direccion VARCHAR(100) NULL,
    correo VARCHAR(100) NULL,
    telefono VARCHAR(20) NULL
);

-- Tabla: MODELOS
CREATE TABLE MODELO (
    id_modelo INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    id_marca INT NOT NULL,
    FOREIGN KEY (id_marca) REFERENCES MARCA(id_marca)
);

-- Tabla principal: MOTOS
CREATE TABLE MOTO (
    id_moto INT AUTO_INCREMENT PRIMARY KEY,
    id_modelo INT NOT NULL,
    id_tipo INT NOT NULL,
    id_propietario INT NOT NULL,
    id_color INT NOT NULL, -- Ahora el color está en MOTO en lugar de MODELO
    FOREIGN KEY (id_modelo) REFERENCES MODELO(id_modelo),
    FOREIGN KEY (id_tipo) REFERENCES TIPO(id_tipo),
    FOREIGN KEY (id_propietario) REFERENCES PROPIETARIO(id_propietario),
    FOREIGN KEY (id_color) REFERENCES COLOR(id_color)
);

-- Tabla: SEGURO
CREATE TABLE SEGURO (
    id_seguro INT AUTO_INCREMENT PRIMARY KEY,
    id_moto INT NOT NULL,
    empresa VARCHAR(50) NOT NULL,
    poliza VARCHAR(50) NOT NULL,
    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NOT NULL,
    tipo_cobertura VARCHAR(50),
    costo DECIMAL(10,2),
    FOREIGN KEY (id_moto) REFERENCES MOTO(id_moto) ON DELETE CASCADE
);

-- Tabla: VENTA
CREATE TABLE VENTA (
    id_venta INT AUTO_INCREMENT PRIMARY KEY,
    id_moto INT NOT NULL,
    id_comprador INT NOT NULL,
    fecha_venta DATE NOT NULL,
    precio_venta DECIMAL(10,2),
    tipo_venta VARCHAR(50) NOT NULL,
    FOREIGN KEY (id_moto) REFERENCES MOTO(id_moto) ON DELETE CASCADE,
    FOREIGN KEY (id_comprador) REFERENCES PROPIETARIO(id_propietario)
);
