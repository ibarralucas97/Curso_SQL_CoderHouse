-- DCL
-- CREAMOS USUARIO COMPRADOR
CREATE USER 'comprador'@'localhost' IDENTIFIED BY 'comprador123';

-- Tendra permisos de lectura sobre las tablas MOTO y VENTA
GRANT SELECT ON MotosDB.MOTO TO 'comprador'@'localhost';
GRANT SELECT ON MotosDB.VENTA TO 'comprador'@'localhost';


-- CREAMOS USUARIO VENDEDOR
CREATE USER 'vendedor'@'localhost' IDENTIFIED BY 'vendedor456';

-- Permiso de lectura sobre las tablas MOTO y VENTA
GRANT SELECT ON MotosDB.MOTO TO 'vendedor'@'localhost';
GRANT SELECT ON MotosDB.VENTA TO 'vendedor'@'localhost';

-- Permisos de inserción sobre la tabla VENTA
GRANT INSERT ON MotosDB.VENTA TO 'vendedor'@'localhost';


-- VERIFICAR PERMISOS
SHOW GRANTS FOR 'comprador'@'localhost';
SHOW GRANTS FOR 'vendedor'@'localhost';

-- ELIMINACION DE PERMISOS
REVOKE SELECT, INSERT ON MotosDB.VENTA FROM 'vendedor'@'localhost';
REVOKE SELECT ON MotosDB.VENTA FROM 'comprador'@'localhost';


