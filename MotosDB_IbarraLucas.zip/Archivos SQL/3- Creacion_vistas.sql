-- CREACION DE VISTA 1
CREATE VIEW Vista_Motos_Propietarios AS
SELECT 
    M.id_moto,
    M.id_modelo,
    M.id_tipo,
    P.nombre AS propietario_nombre,
    P.apellido AS propietario_apellido,
    T.nombre AS tipo_moto
FROM MOTO M
JOIN PROPIETARIO P ON M.id_propietario = P.id_propietario
JOIN TIPO T ON M.id_tipo = T.id_tipo;

-- VER VISTA 1
SELECT * FROM Vista_Motos_Propietarios;

-- CREACION DE VISTA 2
CREATE VIEW Vista_Ventas_Motos AS
SELECT 
    V.id_venta,
    V.id_moto,
    M.id_modelo,
    P.nombre AS comprador_nombre,
    P.apellido AS comprador_apellido,
    V.fecha_venta,
    V.precio_venta,
    V.tipo_venta
FROM VENTA V
JOIN MOTO M ON V.id_moto = M.id_moto
JOIN PROPIETARIO P ON V.id_comprador = P.id_propietario;

-- VER VISTA 2
SELECT * FROM Vista_Ventas_Motos;